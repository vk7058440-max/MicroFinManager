# MicroFin Manager — APK बनाने का तरीका

1. ZIP को extract करें।
2. Android Studio खोलें और extracted `MicroFinManager` folder चुनें।
3. Android SDK Platform 35 तथा JDK 17 उपलब्ध रखें।
4. Gradle Sync पूरा होने दें। यदि Android Studio plugin/Gradle का compatible stable update सुझाए, तो उसे apply करें।
5. `Build > Build Bundle(s) / APK(s) > Build APK(s)` चुनें।
6. Debug APK सामान्यतः `app/build/outputs/apk/debug/app-debug.apk` पर बनेगा।
7. फोन में टेस्ट करने के लिए APK को सुरक्षित तरीके से अपने Android फोन में भेजें और install करें। Android की अनुमति माँगे जाने पर केवल अपने भरोसेमंद build को install करें।

## पहले क्या टेस्ट करें
- ब्रांच जोड़ें, फिर ग्राहक जोड़ें।
- CGT और GRT रिकॉर्ड सेव करें।
- ग्राहक चुनकर लोन रिकॉर्ड करें।
- Reports में CSV export करें और Excel में खोलें।
- भाषा Hindi/English बदलकर देखें।

## ध्यान दें
यह source starter इस environment में Android SDK/Gradle build के साथ compile या device-test नहीं किया गया है। इसलिए इसे तैयार APK या production-ready software न मानें। असली ग्राहक का KYC, बैंक या वित्तीय डेटा डालने से पहले security, authentication, access controls, encrypted storage/backup, audit logs और compliance review पूरा करें।
