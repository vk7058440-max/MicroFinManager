package com.microfin.manager

import android.content.ContentValues
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.room.withTransaction
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class Screen { HOME, CUSTOMER, BRANCH, CGT, GRT, LOAN, REPORTS }
private enum class Lang { HI, EN }
private enum class Role { ADMIN, MANAGER, OFFICER }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = FinanceDb.get(this)
        setContent { MaterialTheme { MicroFinApp(db) } }
    }
}

@Composable
private fun MicroFinApp(db: FinanceDb) {
    val ctx = LocalContext.current
    val dao = db.dao()
    val scope = rememberCoroutineScope()
    var lang by remember { mutableStateOf(Lang.HI) }
    var role by remember { mutableStateOf(Role.ADMIN) }
    var screen by remember { mutableStateOf(Screen.HOME) }
    val branches by dao.branches().collectAsState(initial = emptyList())
    val customers by dao.customers().collectAsState(initial = emptyList())
    val cgt by dao.cgtMeetings().collectAsState(initial = emptyList())
    val grt by dao.grtRecords().collectAsState(initial = emptyList())
    val loans by dao.loans().collectAsState(initial = emptyList())
    val hi = lang == Lang.HI
    fun t(h: String, e: String) = if (hi) h else e

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("MicroFin Manager") },
                actions = {
                    TextButton(onClick = { lang = if (hi) Lang.EN else Lang.HI }) {
                        Text(if (hi) "English" else "हिंदी")
                    }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(t("भूमिका", "Role"), modifier = Modifier.padding(top = 12.dp))
                Role.values().forEach { r ->
                    FilterChip(selected = role == r, onClick = { role = r },
                        label = { Text(when (r) {
                            Role.ADMIN -> t("Admin", "Admin")
                            Role.MANAGER -> t("ब्रांच मैनेजर", "Branch Manager")
                            Role.OFFICER -> t("फील्ड ऑफिसर", "Field Officer")
                        }) })
                }
            }
            NavigationBar {
                listOf(Screen.HOME, Screen.CUSTOMER, Screen.BRANCH, Screen.CGT, Screen.GRT, Screen.LOAN, Screen.REPORTS).forEach { s ->
                    NavigationBarItem(
                        selected = screen == s,
                        onClick = { screen = s },
                        icon = { Icon(when (s) {
                            Screen.HOME -> Icons.Default.Home
                            Screen.CUSTOMER -> Icons.Default.Person
                            Screen.BRANCH -> Icons.Default.Business
                            Screen.CGT -> Icons.Default.Groups
                            Screen.GRT -> Icons.Default.VerifiedUser
                            Screen.LOAN -> Icons.Default.AccountBalance
                            Screen.REPORTS -> Icons.Default.Assessment
                        }, contentDescription = null) },
                        label = { Text(when(s) {
                            Screen.HOME -> t("होम","Home")
                            Screen.CUSTOMER -> t("ग्राहक","Customer")
                            Screen.BRANCH -> t("ब्रांच","Branch")
                            Screen.CGT -> "CGT"
                            Screen.GRT -> "GRT"
                            Screen.LOAN -> t("लोन","Loan")
                            Screen.REPORTS -> t("रिपोर्ट","Reports")
                        }) }
                    )
                }
            }
            when (screen) {
                Screen.HOME -> HomeScreen(hi, branches.size, customers.size, loans.size, cgt.size, grt.size)
                Screen.CUSTOMER -> CustomerScreen(hi, branches, customers) { x -> scope.launch { dao.addCustomer(x) } }
                Screen.BRANCH -> BranchScreen(hi, branches) { x -> scope.launch { dao.addBranch(x) } }
                Screen.CGT -> CgtScreen(hi, cgt) { x -> scope.launch { dao.addCgt(x) } }
                Screen.GRT -> GrtScreen(hi, grt) { x -> scope.launch { dao.addGrt(x) } }
                Screen.LOAN -> LoanScreen(hi, customers, branches, loans) { x -> scope.launch { dao.addLoan(x) } }
                Screen.REPORTS -> ReportsScreen(hi, branches, customers, cgt, grt, loans) { name, csv ->
                    exportCsv(ctx, name, csv)
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(hi: Boolean, branches: Int, customers: Int, loans: Int, cgt: Int, grt: Int) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(if (hi) "ऑपरेशन्स डैशबोर्ड" else "Operations Dashboard", style = MaterialTheme.typography.headlineSmall)
        Text(if (hi) "शुरुआती ऑफलाइन वर्ज़न" else "Offline starter version", style = MaterialTheme.typography.bodyMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard(if (hi) "ब्रांच" else "Branches", branches, Modifier.weight(1f))
            StatCard(if (hi) "ग्राहक" else "Customers", customers, Modifier.weight(1f))
            StatCard(if (hi) "लोन" else "Loans", loans, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard("CGT", cgt, Modifier.weight(1f))
            StatCard("GRT", grt, Modifier.weight(1f))
        }
        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(if (hi) "वर्कफ़्लो" else "Workflow", style = MaterialTheme.typography.titleMedium)
                Text(if (hi) "1. ब्रांच बनाएँ  2. ग्राहक जोड़ें  3. CGT दर्ज करें  4. GRT सत्यापन  5. लोन दर्ज करें" else "1. Create branch  2. Add customer  3. Record CGT  4. Verify GRT  5. Record loan")
            }
        }
        Text(if (hi) "ध्यान दें: इस डेमो में भूमिका चयन वास्तविक लॉगिन या सुरक्षा नहीं है।" else "Note: role selection in this demo is not real authentication or security.", color = MaterialTheme.colorScheme.error)
    }
}

@Composable
private fun StatCard(title: String, value: Int, modifier: Modifier = Modifier) {
    Card(modifier) { Column(Modifier.padding(12.dp)) { Text(title, style = MaterialTheme.typography.labelMedium); Text("$value", style = MaterialTheme.typography.headlineMedium) } }
}

@Composable
private fun CustomerScreen(hi: Boolean, branches: List<Branch>, customers: List<Customer>, save: (Customer) -> Unit) {
    var name by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }; var business by remember { mutableStateOf("") }
    var group by remember { mutableStateOf("") }; var branchId by remember { mutableLongStateOf(branches.firstOrNull()?.id ?: 0L) }
    FormScreen(if (hi) "ग्राहक एंट्री" else "Customer Entry") {
        Field(if (hi) "ग्राहक का नाम" else "Customer name", name) { name = it }
        Field(if (hi) "मोबाइल नंबर" else "Mobile number", phone) { phone = it }
        Field(if (hi) "पता" else "Address", address) { address = it }
        Field(if (hi) "व्यवसाय" else "Business", business) { business = it }
        Field(if (hi) "समूह का नाम" else "Group name", group) { group = it }
        if (branches.isNotEmpty()) {
            Text(if (hi) "ब्रांच चुनें" else "Select branch")
            branches.forEach { b -> Row { RadioButton(branchId == b.id, { branchId = b.id }); Text("${b.name} (${b.code})", modifier = Modifier.padding(top = 12.dp)) } }
        } else Text(if (hi) "पहले ब्रांच बनाएँ" else "Create a branch first")
        Button(onClick = { if (name.isNotBlank() && branches.any { it.id == branchId }) { save(Customer(name=name.trim(), phone=phone.trim(), address=address.trim(), business=business.trim(), branchId=branchId, groupName=group.trim())); name=""; phone=""; address=""; business=""; group="" } }) { Text(if (hi) "ग्राहक सेव करें" else "Save customer") }
        Text(if (hi) "ग्राहक सूची" else "Customer list", style = MaterialTheme.typography.titleMedium)
        customers.forEach { Text("#${it.id}  ${it.name}  •  ${it.phone}") }
    }
}

@Composable
private fun BranchScreen(hi: Boolean, branches: List<Branch>, save: (Branch) -> Unit) {
    var code by remember { mutableStateOf("") }; var name by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }; var manager by remember { mutableStateOf("") }
    FormScreen(if (hi) "ब्रांच एंट्री" else "Branch Entry") {
        Field(if (hi) "ब्रांच कोड" else "Branch code", code) { code = it }
        Field(if (hi) "ब्रांच का नाम" else "Branch name", name) { name = it }
        Field(if (hi) "पता" else "Address", address) { address = it }
        Field(if (hi) "ब्रांच मैनेजर" else "Branch Manager", manager) { manager = it }
        Button(onClick = { if (code.isNotBlank() && name.isNotBlank()) { save(Branch(code=code.trim(), name=name.trim(), address=address.trim(), manager=manager.trim())); code=""; name=""; address=""; manager="" } }) { Text(if (hi) "ब्रांच सेव करें" else "Save branch") }
        branches.forEach { Text("${it.code} • ${it.name} • ${it.manager}") }
    }
}

@Composable
private fun CgtScreen(hi: Boolean, records: List<CgtMeeting>, save: (CgtMeeting) -> Unit) {
    var group by remember { mutableStateOf("") }; var date by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var attendees by remember { mutableStateOf("0") }; var result by remember { mutableStateOf("Pending") }; var notes by remember { mutableStateOf("") }
    FormScreen(if (hi) "CGT मीटिंग" else "CGT Meeting") {
        Field(if (hi) "समूह का नाम" else "Group name", group) { group = it }
        Field(if (hi) "तारीख (YYYY-MM-DD)" else "Date (YYYY-MM-DD)", date) { date = it }
        Field(if (hi) "उपस्थित सदस्य" else "Attendees", attendees) { attendees = it }
        Field(if (hi) "स्टेटस: Pending/Pass/Fail" else "Status: Pending/Pass/Fail", result) { result = it }
        Field(if (hi) "नोट्स" else "Notes", notes) { notes = it }
        Button(onClick = { if (group.isNotBlank()) { save(CgtMeeting(groupName=group.trim(), meetingDate=date.trim(), attendees=attendees.toIntOrNull() ?: 0, result=result.trim(), notes=notes.trim())); group=""; notes="" } }) { Text(if (hi) "CGT सेव करें" else "Save CGT") }
        records.forEach { Text("${it.groupName} • ${it.meetingDate} • ${it.result}") }
    }
}

@Composable
private fun GrtScreen(hi: Boolean, records: List<GrtVerification>, save: (GrtVerification) -> Unit) {
    var customer by remember { mutableStateOf("") }; var date by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var status by remember { mutableStateOf("Pending") }; var reason by remember { mutableStateOf("") }
    FormScreen(if (hi) "GRT सत्यापन" else "GRT Verification") {
        Field(if (hi) "ग्राहक का नाम" else "Customer name", customer) { customer = it }
        Field(if (hi) "विज़िट तारीख" else "Visit date (YYYY-MM-DD)", date) { date = it }
        Field(if (hi) "स्टेटस: Pending/Pass/Reject" else "Status: Pending/Pass/Reject", status) { status = it }
        Field(if (hi) "कारण / नोट्स" else "Reason / notes", reason) { reason = it }
        Button(onClick = { if (customer.isNotBlank()) { save(GrtVerification(customerName=customer.trim(), visitDate=date.trim(), status=status.trim(), reason=reason.trim())); customer=""; reason="" } }) { Text(if (hi) "GRT सेव करें" else "Save GRT") }
        records.forEach { Text("${it.customerName} • ${it.visitDate} • ${it.status}") }
    }
}

@Composable
private fun LoanScreen(hi: Boolean, customers: List<Customer>, branches: List<Branch>, loans: List<Loan>, save: (Loan) -> Unit) {
    var customerId by remember { mutableLongStateOf(customers.firstOrNull()?.id ?: 0L) }
    var branchId by remember { mutableLongStateOf(branches.firstOrNull()?.id ?: 0L) }
    var amount by remember { mutableStateOf("") }; var term by remember { mutableStateOf("12") }
    var rate by remember { mutableStateOf("24") }; var status by remember { mutableStateOf("Approved") }
    var date by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }; var ref by remember { mutableStateOf("") }
    FormScreen(if (hi) "लोन डिस्बर्समेंट" else "Loan Disbursement") {
        if (customers.isEmpty()) Text(if (hi) "पहले ग्राहक जोड़ें" else "Add a customer first")
        customers.forEach { c -> Row { RadioButton(customerId == c.id, { customerId = c.id }); Text("${c.name} (#${c.id})", modifier = Modifier.padding(top = 12.dp)) } }
        Field(if (hi) "लोन राशि (₹)" else "Loan amount (INR)", amount) { amount = it }
        Field(if (hi) "अवधि (महीने)" else "Term (months)", term) { term = it }
        Field(if (hi) "वार्षिक ब्याज दर (%)" else "Annual rate (%)", rate) { rate = it }
        Field(if (hi) "स्टेटस: Approved/Disbursed/Rejected" else "Status: Approved/Disbursed/Rejected", status) { status = it }
        Field(if (hi) "डिस्बर्समेंट तारीख" else "Disbursement date (YYYY-MM-DD)", date) { date = it }
        Field(if (hi) "ट्रांजैक्शन रेफरेंस" else "Transaction reference", ref) { ref = it }
        Button(onClick = {
            val customer = customers.find { it.id == customerId }
            val amt = amount.toDoubleOrNull()
            if (customer != null && amt != null && amt > 0 && term.toIntOrNull() != null && branches.any { it.id == customer.branchId }) {
                save(Loan(customerId=customer.id, customerName=customer.name, branchId=customer.branchId, amount=amt, termMonths=term.toIntOrNull() ?: 12, annualRatePercent=rate.toDoubleOrNull() ?: 0.0, status=status.trim(), disbursementDate=date.trim(), transactionRef=ref.trim()))
                amount=""; ref=""
            }
        }) { Text(if (hi) "लोन रिकॉर्ड सेव करें" else "Save loan record") }
        loans.forEach { Text("#${it.id} • ${it.customerName} • ₹${"%.2f".format(it.amount)} • ${it.status}") }
        Text(if (hi) "MVP में EMI/बकाया गणना नहीं है; भुगतान कलेक्शन शामिल नहीं है।" else "EMI/outstanding calculation is not included; repayments are out of scope.", color = MaterialTheme.colorScheme.error)
    }
}

@Composable
private fun ReportsScreen(hi: Boolean, branches: List<Branch>, customers: List<Customer>, cgt: List<CgtMeeting>, grt: List<GrtVerification>, loans: List<Loan>, export: (String, String) -> Unit) {
    FormScreen(if (hi) "रिपोर्ट और Excel" else "Reports & Excel") {
        Text(if (hi) "CSV फ़ाइल Excel में खुल जाएगी।" else "CSV files open in Excel.")
        Button(onClick = { export("customers.csv", csv("id,name,phone,address,business,branch_id,group", customers.map { listOf(it.id,it.name,it.phone,it.address,it.business,it.branchId,it.groupName) })) }, modifier = Modifier.fillMaxWidth()) { Text(if (hi) "ग्राहक रिपोर्ट एक्सपोर्ट" else "Export customer report") }
        Button(onClick = { export("branches.csv", csv("id,code,name,address,manager", branches.map { listOf(it.id,it.code,it.name,it.address,it.manager) })) }, modifier = Modifier.fillMaxWidth()) { Text(if (hi) "ब्रांच-वाइज रिपोर्ट एक्सपोर्ट" else "Export branch report") }
        Button(onClick = { export("cgt.csv", csv("id,group,date,attendees,result,notes", cgt.map { listOf(it.id,it.groupName,it.meetingDate,it.attendees,it.result,it.notes) })) }, modifier = Modifier.fillMaxWidth()) { Text(if (hi) "CGT रिपोर्ट एक्सपोर्ट" else "Export CGT report") }
        Button(onClick = { export("grt.csv", csv("id,customer,visit_date,status,reason", grt.map { listOf(it.id,it.customerName,it.visitDate,it.status,it.reason) })) }, modifier = Modifier.fillMaxWidth()) { Text(if (hi) "GRT रिपोर्ट एक्सपोर्ट" else "Export GRT report") }
        Button(onClick = { export("loan_history_disbursement.csv", csv("loan_id,customer_id,customer,branch_id,amount,term_months,annual_rate,status,date,transaction_ref", loans.map { listOf(it.id,it.customerId,it.customerName,it.branchId,it.amount,it.termMonths,it.annualRatePercent,it.status,it.disbursementDate,it.transactionRef) })) }, modifier = Modifier.fillMaxWidth()) { Text(if (hi) "लोन हिस्ट्री / डिस्बर्समेंट एक्सपोर्ट" else "Export loan history / disbursement") }
        Text(if (hi) "बकाया किस्त रिपोर्ट के लिए repayment/collection डेटा आवश्यक है। अभी वास्तविक overdue रिपोर्ट उपलब्ध नहीं है।" else "Actual overdue instalment reporting requires repayment/collection data and is not available in this MVP.", color = MaterialTheme.colorScheme.error)
    }
}

private fun csv(headers: String, rows: List<List<Any?>>): String {
    fun cell(v: Any?): String = "\"" + (v?.toString() ?: "").replace("\"", "\"\"") + "\""
    return "\uFEFF" + headers + "\r\n" + rows.joinToString("\r\n") { row -> row.joinToString(",") { cell(it) } }
}

private fun exportCsv(context: android.content.Context, name: String, content: String) {
    try {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, "text/csv")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MicroFinManager")
        }
        val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
        if (uri != null) context.contentResolver.openOutputStream(uri)?.use { it.write(content.toByteArray(Charsets.UTF_8)) }
        Toast.makeText(context, if (uri != null) "Saved to Downloads/MicroFinManager/$name" else "Export failed", Toast.LENGTH_LONG).show()
    } catch (e: Exception) {
        Toast.makeText(context, "Export failed: ${e.message}", Toast.LENGTH_LONG).show()
    }
}

@Composable
private fun FormScreen(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = {
        Text(title, style = MaterialTheme.typography.headlineSmall)
        content()
    })
}

@Composable
private fun Field(label: String, value: String, onValue: (String) -> Unit) {
    OutlinedTextField(value, onValue, label = { Text(label) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
}
