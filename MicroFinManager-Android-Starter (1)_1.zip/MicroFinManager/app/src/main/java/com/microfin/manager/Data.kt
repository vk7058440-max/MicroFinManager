package com.microfin.manager

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "branches")
data class Branch(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val code: String,
    val name: String,
    val address: String,
    val manager: String
)

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String,
    val address: String,
    val business: String,
    val branchId: Long,
    val groupName: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "cgt")
data class CgtMeeting(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val groupName: String,
    val meetingDate: String,
    val attendees: Int,
    val result: String,
    val notes: String
)

@Entity(tableName = "grt")
data class GrtVerification(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerName: String,
    val visitDate: String,
    val status: String,
    val reason: String
)

@Entity(tableName = "loans")
data class Loan(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long,
    val customerName: String,
    val branchId: Long,
    val amount: Double,
    val termMonths: Int,
    val annualRatePercent: Double,
    val status: String,
    val disbursementDate: String,
    val transactionRef: String
)

@Dao
interface FinanceDao {
    @Query("SELECT * FROM branches ORDER BY name") fun branches(): Flow<List<Branch>>
    @Query("SELECT * FROM customers ORDER BY id DESC") fun customers(): Flow<List<Customer>>
    @Query("SELECT * FROM cgt ORDER BY id DESC") fun cgtMeetings(): Flow<List<CgtMeeting>>
    @Query("SELECT * FROM grt ORDER BY id DESC") fun grtRecords(): Flow<List<GrtVerification>>
    @Query("SELECT * FROM loans ORDER BY id DESC") fun loans(): Flow<List<Loan>>
    @Insert suspend fun addBranch(x: Branch)
    @Insert suspend fun addCustomer(x: Customer)
    @Insert suspend fun addCgt(x: CgtMeeting)
    @Insert suspend fun addGrt(x: GrtVerification)
    @Insert suspend fun addLoan(x: Loan)
    @Query("SELECT COUNT(*) FROM customers") suspend fun customerCount(): Int
    @Query("SELECT COUNT(*) FROM branches") suspend fun branchCount(): Int
    @Query("SELECT COUNT(*) FROM loans") suspend fun loanCount(): Int
}

@Database(entities = [Branch::class, Customer::class, CgtMeeting::class, GrtVerification::class, Loan::class], version = 1, exportSchema = false)
abstract class FinanceDb : RoomDatabase() {
    abstract fun dao(): FinanceDao
    companion object {
        @Volatile private var INSTANCE: FinanceDb? = null
        fun get(context: Context): FinanceDb = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, FinanceDb::class.java, "microfin-manager.db")
                .build().also { INSTANCE = it }
        }
    }
}
