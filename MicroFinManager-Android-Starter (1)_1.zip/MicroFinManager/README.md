# MicroFin Manager — Android MVP

A bilingual (Hindi/English) offline-first starter app for microfinance operations.

## Included in this starter
- Customer entry and searchable customer list
- Branch entry and branch list
- CGT meeting record
- GRT verification record
- Loan application/disbursement record
- Summary dashboard
- CSV report export (opens in Excel; UTF-8 BOM included)
- Local SQLite persistence via Android Room
- Admin / Branch Manager / Field Officer role selector (prototype UI only)

## Important limitations
This is a **starter source project**, not a signed/installable APK. It has not been built or tested in this environment. You need Android Studio + Android SDK to build it. The role selector is only a prototype: production authentication and server-enforced permissions are not implemented. Data is stored locally on one device; no cloud sync, backup, encryption-at-rest policy, audit trail, or remote administration is configured. Do not enter real customer KYC/bank details until these protections are implemented and reviewed.

## Build
1. Install Android Studio (current stable) and Android SDK.
2. Open this folder as a project.
3. Let Gradle sync.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK is usually at `app/build/outputs/apk/debug/app-debug.apk`.

If Android Studio asks to install a compatible Gradle/Android plugin, accept its recommended stable version.

## Suggested production architecture
- Android: Kotlin + Jetpack Compose (or XML), Room local cache, WorkManager sync queue.
- Backend: REST API (Ktor/Spring Boot/Node), PostgreSQL, object storage for KYC images.
- Auth: short-lived access tokens, refresh tokens, password reset, device/session management.
- Authorization: server-side role + branch scoping on every endpoint.
- Security: TLS, encrypted local database/keys, Android Keystore, minimal KYC retention, access logs, backups and restore tests.
- Reports: server-generated XLSX for larger data; CSV export in this MVP.
- Workflow: customer → group/CGT → GRT → loan approval → disbursement.
- Audit: immutable events for approvals, changes, and disbursements; idempotency keys for financial writes.
- Compliance: have Indian legal/compliance counsel review RBI/NBFC/partner requirements, KYC, privacy, retention, and consent before deployment.

## Reports
The MVP exports one CSV report at a time:
- Customers
- Branches
- CGT meetings
- GRT verification
- Loan disbursements / loan history
- Outstanding instalments are **not calculated** because repayment collection is intentionally out of scope. The report can list loan principal/term, but it cannot claim actual overdue amounts without a repayment ledger.

## Next steps
1. Replace prototype role selector with real authentication and server-side access control.
2. Add backend and organization/branch tenancy.
3. Implement encrypted backups and sync/conflict handling.
4. Add approval limits and maker-checker controls for disbursement.
5. Add a repayment ledger if collection/actual overdue reporting is later required.
